package com.egorpoprotskiy.solobase.di

import com.egorpoprotskiy.solobase.data.reminder.AndroidTaskReminderScheduler
import com.egorpoprotskiy.solobase.data.remote.firestore.repository.FirestoreProjectRepositoryImpl
import com.egorpoprotskiy.solobase.data.repository.NoteRepositoryImpl
import com.egorpoprotskiy.solobase.data.repository.ProjectRepositoryImpl
import com.egorpoprotskiy.solobase.data.repository.TaskRepositoryImpl
import com.egorpoprotskiy.solobase.domain.reminder.TaskReminderScheduler
import com.egorpoprotskiy.solobase.domain.repository.NoteRepository
import com.egorpoprotskiy.solobase.domain.repository.ProjectRepository
import com.egorpoprotskiy.solobase.domain.repository.TaskRepository
import com.egorpoprotskiy.solobase.domain.repository.remote.FirestoreProjectRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import com.egorpoprotskiy.solobase.data.remote.firestore.repository.FirestoreTaskRepositoryImpl
import com.egorpoprotskiy.solobase.domain.repository.remote.FirestoreTaskRepository
import com.egorpoprotskiy.solobase.data.remote.firestore.repository.FirestoreNoteRepositoryImpl
import com.egorpoprotskiy.solobase.domain.repository.remote.FirestoreNoteRepository

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds
    @Singleton
    abstract fun bindTaskRepository(
        taskRepositoryImpl: TaskRepositoryImpl
    ): TaskRepository

    @Binds
    @Singleton
    abstract fun bindProjectRepository(
        projectRepositoryImpl: ProjectRepositoryImpl
    ): ProjectRepository

    @Binds
    @Singleton
    abstract fun bindNoteRepository(
        noteRepositoryImpl: NoteRepositoryImpl
    ): NoteRepository

    @Binds
    @Singleton
    abstract fun bindTaskReminderScheduler(
        androidTaskReminderScheduler: AndroidTaskReminderScheduler
    ): TaskReminderScheduler

    @Binds
    @Singleton
    abstract fun bindFirestoreProjectRepository(
        firestoreProjectRepositoryImpl: FirestoreProjectRepositoryImpl
    ): FirestoreProjectRepository

    @Binds
    @Singleton
    abstract fun bindFirestoreTaskRepository(
        implementation: FirestoreTaskRepositoryImpl
    ): FirestoreTaskRepository

    @Binds
    @Singleton
    abstract fun bindFirestoreNoteRepository(
        implementation: FirestoreNoteRepositoryImpl
    ): FirestoreNoteRepository
}
